package com.example.karthik.lvg1;

import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView one,two;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one=(TextView)findViewById(R.id.signin);
        two=(TextView)findViewById(R.id.register);
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager m=getFragmentManager();
                fragment1 obj=new fragment1();
                m.beginTransaction().replace(R.id.replacer,obj)
                        .commit();
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager on=getFragmentManager();
                fragment2 o=new fragment2();
                on.beginTransaction().replace(R.id.replacer,o)
                        .commit();
            }
        });


    }
}
