package com.example.karthik.checkbox_androidclass;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

/**
 * Created by karthik on 20/6/17.
 */

public class second extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
    }
    public void SelectGender(View view){
        boolean checked=((RadioButton)view).isChecked();
        switch (view.getId()){
            case  R.id.radioButton2:
                if (checked)
                    Toast.makeText(getApplicationContext(),"Male",Toast.LENGTH_LONG).show();
                else
                    break;
            case R.id.radioButton3:
                if (checked)
                    Toast.makeText(getApplicationContext(),"Female",Toast.LENGTH_LONG).show();
                else
                    break;
            case R.id.radioButton4:
                if (checked)
                    Toast.makeText(getApplicationContext(),"Others",Toast.LENGTH_LONG).show();
                else
                    break;
                default:
                    Toast.makeText(getApplicationContext(),"No option selected",Toast.LENGTH_LONG).show();

        }
    }
}
