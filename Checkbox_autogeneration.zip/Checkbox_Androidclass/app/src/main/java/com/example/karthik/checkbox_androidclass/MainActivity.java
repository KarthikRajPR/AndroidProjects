package com.example.karthik.checkbox_androidclass;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends Activity{
     EditText selectedCourse;
    String one,two,three;
    TextView ViewCourse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewCourse=(TextView)findViewById(R.id.textView);
        ViewCourse.setEnabled(false);
        selectedCourse=(EditText)findViewById(R.id.editText);

    }
    public void SelectedCourses(View view){
        boolean checked=((CheckBox)view).isChecked();
        switch (view.getId()){
            case R.id.checkBox:
                if (checked)
                    call("MCA","","");


                break;
            case R.id.checkBox2:
                if (checked)
                    call("","MCS","");
                break;
            case R.id.checkBox3:
                if (checked)
                    call("","","MBA");

                break;
            default:
                call("MCA","MCS","MBA");
        }
    }
    public void call(String one,String two,String three){
            String controlled=one+two+three;
            selectedCourse.setText(controlled);

    }
}
