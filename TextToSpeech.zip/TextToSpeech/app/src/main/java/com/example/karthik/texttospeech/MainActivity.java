package com.example.karthik.texttospeech;

import android.app.Activity;
import android.content.DialogInterface;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    TextToSpeech a;
    EditText b;
    Button c,c1;
    Spinner spinner;
    String language;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=(EditText)findViewById(R.id.editText);
        c=(Button)findViewById(R.id.button);
        c1=(Button)findViewById(R.id.button2);
        spinner=(Spinner)findViewById(R.id.spinner);
        ArrayAdapter<String> adapter;
        List<String> list;
        list=new ArrayList<String>();
        list.add("English");
        list.add("French");
        list.add("German");
        list.add("Japanese");
        adapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,list);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                language=spinner.getSelectedItem().toString();
                if (language.equalsIgnoreCase("English")){
                    a=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if(status!=TextToSpeech.ERROR){
                                a.setLanguage(Locale.UK);
                            }
                        }
                    });
                    c.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String string=b.getText().toString();
                            if (string.length()>0){
                                Toast.makeText(getApplicationContext(), string,Toast.LENGTH_LONG).show();
                                a.speak(string,TextToSpeech.QUEUE_FLUSH,null);
                            }
                            else
                            {
                                b.setError("Enter the Text to Speak!!!");
                            }

                        }
                    });
                    c1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            b.setText("");
                        }
                    });
                }
                else if(language.equalsIgnoreCase("French"))
                {
                    a=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if(status!=TextToSpeech.ERROR){
                                a.setLanguage(Locale.FRENCH);
                            }
                        }
                    });
                    c.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String string=b.getText().toString();
                            if (string.length()>0){
                                Toast.makeText(getApplicationContext(), string,Toast.LENGTH_LONG).show();
                                a.speak(string,TextToSpeech.QUEUE_FLUSH,null);
                            }
                            else
                            {
                                b.setError("Enter the Text to Speak!!!");
                            }

                        }
                    });
                    c1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            b.setText("");
                        }
                    });
                }
                else if(language.equalsIgnoreCase("German"))
                {
                    a=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if(status!=TextToSpeech.ERROR){
                                a.setLanguage(Locale.GERMAN);
                            }
                        }
                    });
                    c.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String string=b.getText().toString();
                            if (string.length()>0){
                                Toast.makeText(getApplicationContext(), string,Toast.LENGTH_LONG).show();
                                a.speak(string,TextToSpeech.QUEUE_FLUSH,null);
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Enter the Text to speak!!",Toast.LENGTH_LONG).show();
                            }

                        }
                    });
                    c1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(b.getText().length()<=0){
                                b.setError("No Text to clear further!");
                            }
                            else{
                                b.setText("");
                            }


                        }
                    });
                }
                else if(language.equalsIgnoreCase("Japanese"))
                {
                    a=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if(status!=TextToSpeech.ERROR){
                                a.setLanguage(Locale.JAPANESE);
                            }
                        }
                    });
                    c.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String string=b.getText().toString();
                            if (string.length()>0){
                                Toast.makeText(getApplicationContext(), string,Toast.LENGTH_LONG).show();
                                a.speak(string,TextToSpeech.QUEUE_FLUSH,null);
                            }
                            else
                            {
                                b.setError("Enter the Text to Speak!!!");
                            }

                        }
                    });
                    c1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            b.setText("");

                        }
                    });
                }
                else{
                    Toast.makeText(getApplicationContext(),"No language found",Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
    @Override
    public void onPause(){
        if(a!=null){
            a.stop();
            a.shutdown();
        }
        super.onPause();
    }
}
